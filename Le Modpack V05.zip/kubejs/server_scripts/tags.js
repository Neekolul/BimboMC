onEvent('tags.items', event => {
    event.remove('forge:cobblestone', 'minecraft:mossy_cobblestone');
    //Barrels
    event.add('forge:barrels/wooden', ['betternether:barrel_anchor_tree',
        'betternether:barrel_nether_sakura',
        'betternether:barrel_crimson',
        'betternether:barrel_warped',
        'betternether:barrel_stalagnate',
        'betternether:barrel_reed',
        'betternether:barrel_willow',
        'betternether:barrel_wart',
        'betternether:barrel_rubeus',
        'betternether:barrel_mushroom',
        'betternether:barrel_mushroom_fir',
        'charm:oak_barrel',
        'charm:spruce_barrel',
        'charm:birch_barrel',
        'charm:jungle_barrel',
        'charm:acacia_barrel',
        'charm:dark_oak_barrel',
        'charm:crimson_barrel',
        'charm:warped_barrel',
        'crumbs:oak_barrel',
        'crumbs:birch_barrel',
        'crumbs:jungle_barrel',
        'crumbs:acacia_barrel',
        'crumbs:dark_oak_barrel',
        'crumbs:crimson_barrel',
        'crumbs:warped_barrel'
    ]);
    //Crafting Tables
    event.add('charm:crafting_tables', ['betternether:crafting_table_anchor_tree',
        'betternether:crafting_table_nether_sakura',
        'betternether:crafting_table_crimson',
        'betternether:crafting_table_warped',
        'betternether:crafting_table_stalagnate',
        'betternether:crafting_table_reed',
        'betternether:crafting_table_willow',
        'betternether:crafting_table_wart',
        'betternether:crafting_table_rubeus',
        'betternether:crafting_table_mushroom',
        'betternether:crafting_table_mushroom_fir',
        'crumbs:spruce_crafting_table',
        'crumbs:birch_crafting_table',
        'crumbs:jungle_crafting_table',
        'crumbs:acacia_crafting_table',
        'crumbs:dark_oak_crafting_table',
        'crumbs:crimson_crafting_table',
        'crumbs:warped_crafting_table',
        'cyclic:workbench',
        'betterendforge:mossy_glowshroom_crafting_table',
        'betterendforge:lacugrove_crafting_table',
        'betterendforge:end_lotus_crafting_table',
        'betterendforge:pythadendron_crafting_table',
        'betterendforge:dragon_tree_crafting_table',
        'betterendforge:tenanea_crafting_table',
        'betterendforge:helix_tree_crafting_table',
        'betterendforge:umbrella_tree_crafting_table',
        'betterendforge:jellyshroom_crafting_table',
        'betterendforge:lucernia_crafting_table'
    ]);

    event.add('refinedstorage:crafting_tables', ['betternether:crafting_table_anchor_tree',
        'betternether:crafting_table_nether_sakura',
        'betternether:crafting_table_crimson',
        'betternether:crafting_table_warped',
        'betternether:crafting_table_stalagnate',
        'betternether:crafting_table_reed',
        'betternether:crafting_table_willow',
        'betternether:crafting_table_wart',
        'betternether:crafting_table_rubeus',
        'betternether:crafting_table_mushroom',
        'betternether:crafting_table_mushroom_fir',
		'crumbs:spruce_crafting_table',
        'crumbs:birch_crafting_table',
        'crumbs:jungle_crafting_table',
        'crumbs:acacia_crafting_table',
        'crumbs:dark_oak_crafting_table',
        'crumbs:crimson_crafting_table',
        'crumbs:warped_crafting_table',
        'cyclic:workbench',
        'betterendforge:mossy_glowshroom_crafting_table',
        'betterendforge:lacugrove_crafting_table',
        'betterendforge:end_lotus_crafting_table',
        'betterendforge:pythadendron_crafting_table',
        'betterendforge:dragon_tree_crafting_table',
        'betterendforge:tenanea_crafting_table',
        'betterendforge:helix_tree_crafting_table',
        'betterendforge:umbrella_tree_crafting_table',
        'betterendforge:jellyshroom_crafting_table',
        'betterendforge:lucernia_crafting_table'
    ]);

    event.add('forge:workbenches', ['betternether:crafting_table_anchor_tree',
        'betternether:crafting_table_nether_sakura',
        'betternether:crafting_table_crimson',
        'betternether:crafting_table_warped',
        'betternether:crafting_table_stalagnate',
        'betternether:crafting_table_reed',
        'betternether:crafting_table_willow',
        'betternether:crafting_table_wart',
        'betternether:crafting_table_rubeus',
        'betternether:crafting_table_mushroom',
        'betternether:crafting_table_mushroom_fir',
        'crumbs:spruce_crafting_table',
        'crumbs:birch_crafting_table',
        'crumbs:jungle_crafting_table',
        'crumbs:acacia_crafting_table',
        'crumbs:dark_oak_crafting_table',
        'crumbs:crimson_crafting_table',
        'crumbs:warped_crafting_table',
        'cyclic:workbench',
        'betterendforge:mossy_glowshroom_crafting_table',
        'betterendforge:lacugrove_crafting_table',
        'betterendforge:end_lotus_crafting_table',
        'betterendforge:pythadendron_crafting_table',
        'betterendforge:dragon_tree_crafting_table',
        'betterendforge:tenanea_crafting_table',
        'betterendforge:helix_tree_crafting_table',
        'betterendforge:umbrella_tree_crafting_table',
        'betterendforge:jellyshroom_crafting_table',
        'betterendforge:lucernia_crafting_table'
    ]);
    //Plants
    event.add('kubeemc:lily', [
        'betterendforge:end_lily_leaf'
    ]);
    event.add('minecraft:saplings', [
        'betternether:nether_sakura_sapling',
        'betternether:anchor_tree_sapling',
        'betternether:willow_sapling',
        'betternether:rubeus_sapling',
        'betternether:mushroom_fir_sapling'
    ]);
    event.add('minecraft:logs', [
        'betternether:striped_log_nether_sakura',
        'betternether:striped_bark_nether_sakura',
        'betternether:nether_sakura_log',
        'betternether:nether_sakura_bark',
        'betternether:striped_log_anchor_tree',
        'betternether:striped_bark_anchor_tree',
        'betternether:anchor_tree_log',
        'betternether:anchor_tree_bark',
        'betternether:striped_log_willow',
        'betternether:striped_bark_willow',
        'betternether:willow_log',
        'betternether:willow_bark',
        'betternether:striped_log_rubeus',
        'betternether:striped_bark_rubeus',
        'betternether:rubeus_log',
        'betternether:rubeus_bark',
        'betternether:striped_log_mushroom_fir',
        'betternether:striped_wood_mushroom_fir',
        'betternether:mushroom_fir_log',
        'betternether:mushroom_fir_wood',
        'betternether:striped_log_wart',
        'betternether:striped_bark_wart',
        'betternether:wart_log',
        'betternether:wart_bark',
        'betternether:striped_log_stalagnate',
        'betternether:striped_bark_stalagnate',
        'betternether:stalagnate_log',
        'betternether:stalagnate_bark'
    ]);
    event.add('minecraft:leaves', [
        'betternether:rubeus_leaves',
        'betternether:willow_leaves',
        'betternether:anchor_tree_leaves',
        'betternether:nether_sakura_leaves',
    ]);
    event.add('kubeemc:stem', [
        'betternether:stalagnate_stem',
        'betternether:mushroom_fir_stem',
        'betterendforge:end_lotus_stem',
        'betternether:mushroom_stem'
    ]);
    //Stone Blocks
    event.add('kubeemc:stone', [
        'betterendforge:umbralith',
        'betterendforge:sandy_jadestone',
        'betterendforge:azure_jadestone',
        'betterendforge:virid_jadestone',
        'betterendforge:sulphuric_rock',
        'betterendforge:violecite',
        'betterendforge:flavolite'
    ]);
	
    event.add('forge:dusts/gold', [
        'create:crushed_gold_ore'
    ]);

    event.add('forge:dusts/iron', [
        'create:crushed_iron_ore'
    ]);

    event.add('forge:dusts/copper', [
        'create:crushed_copper_ore'
    ]);

    event.add('forge:dusts/silver', [
        'create:crushed_silver_ore'
    ]);

    event.add('forge:dusts/tin', [
        'create:crushed_tin_ore'
    ]);

    event.add('forge:dusts/lead', [
        'create:crushed_gold_ore'
    ]);

    event.add('forge:dusts/nickel', [
        'create:crushed_nickel_ore'
    ]);

    event.add('forge:dusts/uranium', [
        'create:crushed_uranium_ore'
    ]);

    event.add('forge:dusts/zinc', [
        'create:crushed_zinc_ore'
    ]);

    event.add('forge:dusts/brass', [
        'create:crushed_brass'
    ]);
})